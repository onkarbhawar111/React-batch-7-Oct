import React from 'react'
import NavBar from './NavBar'

const HomePage = () => {
  return (
    <div>
        <NavBar />
    </div>
  )
}

export default HomePage