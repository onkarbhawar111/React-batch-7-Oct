import React from "react";
import Section from "./Section.jsx";

function MainBody() {
  return (
    <>
      <h2>This is MainBody Component.</h2>
      <Section />
    </>
  );
}

export default MainBody;
