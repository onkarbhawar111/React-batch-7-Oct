import React from "react";

function Section(){
    return(
        <h2>This is Section Comp</h2>
    )
}

export default Section