import React from "react";

function OfferLetter({fname, age}){
    return(
        <>
        <h2>Welcome to Technogrowth S/W Solutions</h2>
        <p>Hello {fname}, we are glad to welcome you in our team. We hope to know each other better and work fro the betterment of us as well as yourself. Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores molestiae excepturi tenetur magni. Error harum facilis ex, blanditiis minus labore optio veniam mollitia consectetur dolores sed neque delectus vitae officiis totam alias provident numquam nulla repudiandae, eaque dolorum! Temporibus totam voluptatem quia necessitatibus animi vel, atque corrupti pariatur ipsam eius, odit aliquid est impedit incidunt facilis quas nihil deleniti at aut explicabo expedita vitae. Iste expedita sunt minus earum voluptatum vero optio, nisi, vitae sequi dolorem non, natus distinctio aut aspernatur veniam deserunt possimus cupiditate molestiae. Corporis totam nemo veritatis suscipit modi nobis provident exercitationem nam, sint, assumenda eligendi officia!</p>
        </>
    )
}

export default OfferLetter