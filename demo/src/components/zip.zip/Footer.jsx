import React from "react";

function Footer(){
    return(
        <h2>This is Footer Comp</h2>
    )
}

export default Footer