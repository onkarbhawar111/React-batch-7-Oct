import React from "react";

function NewComponent({name}){
    return(
        <>
        <h2>This... is {name} Component....</h2>
        </>
    )
}

export default NewComponent