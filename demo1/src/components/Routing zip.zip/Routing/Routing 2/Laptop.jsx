import React from 'react'

const Laptop = () => {
  return (
    <div>Laptop</div>
  )
}

export default Laptop