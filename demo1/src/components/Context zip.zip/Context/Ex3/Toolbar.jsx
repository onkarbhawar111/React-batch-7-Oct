import ThemedBtn from "./ThemedBtn";

export default function Toolbar() {
  return (
    <>
      <div>
        <h1>Theme Toggle Example</h1>
        <ThemedBtn />
      </div>
    </>
  );
}
