import CompB from "./CompB";

export default function CompA(){
    return(
        <>
            <CompB />
        </>
    )
}