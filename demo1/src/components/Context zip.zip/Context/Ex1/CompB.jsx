import CompC from "./CompC";

function CompB() {
  return (
    <>
      <CompC />
    </>
  );
}
export default CompB;
